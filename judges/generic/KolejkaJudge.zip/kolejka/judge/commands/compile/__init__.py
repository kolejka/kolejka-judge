# vim:ts=4:sts=4:sw=4:expandtab


from kolejka.judge import config
from kolejka.judge.commands.compile.base import *
from kolejka.judge.commands.compile.gcc import *
from kolejka.judge.commands.compile.ghc import *
from kolejka.judge.commands.compile.mono import *
from kolejka.judge.commands.compile.nasm import *
