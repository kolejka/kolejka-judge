# vim:ts=4:sts=4:sw=4:expandtab


from kolejka.judge import config

class PrerequirementException(Exception):
    pass
